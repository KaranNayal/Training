package com.practiceQuestions;

import java.util.HashMap;
import java.util.Map;

class URLParser {
    private String url;
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLParser(String url) {
        this.url = url;
        parseURL();
    }

    private void parseURL() {
        // Assuming a URL format like "protocol://host/path?param1=value1&param2=value2"
        String[] parts = url.split("://");
        if (parts.length > 1) {
            protocol = parts[0];
            String remaining = parts[1];
            String[] remainingParts = remaining.split("/", 2);

            host = remainingParts[0];
            if (remainingParts.length > 1) {
                String pathAndQuery = remainingParts[1];
                String[] pathAndQueryParts = pathAndQuery.split("\\?", 2);

                path = pathAndQueryParts[0];

                if (pathAndQueryParts.length > 1) {
                    queryParams = parseQueryParams(pathAndQueryParts[1]);
                }
            }
        }
    }

    private Map<String, String> parseQueryParams(String query) {
        Map<String, String> params = new HashMap<>();
        String[] pairs = query.split("&");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                params.put(keyValue[0], keyValue[1]);
            }
        }
        return params;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getHost() {
        return host;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getQueryParams() {
        return queryParams;
    }
}

class URLBuilder {
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLBuilder() {
        this.queryParams = new HashMap<>();
    }

    public URLBuilder setProtocol(String protocol) {
        this.protocol = protocol;
        return this;
    }

    public URLBuilder setHost(String host) {
        this.host = host;
        return this;
    }

    public URLBuilder setPath(String path) {
        this.path = path;
        return this;
    }

    public URLBuilder addQueryParam(String key, String value) {
        queryParams.put(key, value);
        return this;
    }

    public String build() {
        StringBuilder urlBuilder = new StringBuilder();

        if (protocol != null) {
            urlBuilder.append(protocol).append("://");
        }

        if (host != null) {
            urlBuilder.append(host);
        }

        if (path != null) {
            urlBuilder.append("/").append(path);
        }

        if (!queryParams.isEmpty()) {
            urlBuilder.append("?");
            for (Map.Entry<String, String> entry : queryParams.entrySet()) {
                urlBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            // Remove the trailing "&"
            urlBuilder.setLength(urlBuilder.length() - 1);
        }

        return urlBuilder.toString();
    }
}

public class URLParserAndBuilder{
    public static void main(String[] args) {
        // Example of URL parsing
        String url = "https://www.example.com/path/to/resource?param1=value1&param2=value2";
        URLParser urlParser = new URLParser(url);

        System.out.println("Parsed URL Components:");
        System.out.println("Protocol: " + urlParser.getProtocol());
        System.out.println("Host: " + urlParser.getHost());
        System.out.println("Path: " + urlParser.getPath());
        System.out.println("Query Parameters: " + urlParser.getQueryParams());

        // Example of URL building
        URLBuilder urlBuilder = new URLBuilder();
        urlBuilder.setProtocol("https")
                  .setHost("www.example.com")
                  .setPath("path/to/resource")
                  .addQueryParam("param1", "value1")
                  .addQueryParam("param2", "value2");

        String constructedURL = urlBuilder.build();
        System.out.println("\nConstructed URL: " + constructedURL);
    }
}
