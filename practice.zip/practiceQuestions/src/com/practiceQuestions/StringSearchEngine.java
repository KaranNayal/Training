package com.practiceQuestions;

import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {
    private String originalText;

    // Constructor to initialize the original text
    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    // Find all occurrences of a substring in the original text
    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = originalText.indexOf(substring);
        while (index != -1) {
            occurrences.add(index);
            index = originalText.indexOf(substring, index + 1);
        }
        return occurrences;
    }

    // Highlight matched substrings in the original text
    public String highlightSubstrings(String substring) {
        StringBuilder highlightedText = new StringBuilder(originalText);
        List<Integer> occurrences = findAllOccurrences(substring);

        // Apply highlighting to each occurrence
        for (int i : occurrences) {
            for (int j = i; j < i + substring.length(); j++) {
                highlightedText.setCharAt(j, Character.toUpperCase(originalText.charAt(j)));
            }
        }

        return highlightedText.toString();
    }

    public static void main(String[] args) {
        String text = "This is a sample text. Sample text is used for demonstration.";
        StringSearchEngine searchEngine = new StringSearchEngine(text);

        String substringToSearch = "sample";
        List<Integer> occurrences = searchEngine.findAllOccurrences(substringToSearch);

        System.out.println("Occurrences of '" + substringToSearch + "': " + occurrences);

        String highlightedText = searchEngine.highlightSubstrings(substringToSearch);
        System.out.println("Highlighted Text:\n" + highlightedText);
    }
}
